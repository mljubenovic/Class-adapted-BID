%===================================================================================================%
				Class-adapted BID algorithm
%===================================================================================================%

MATLAB DEMO for the class-adapted BID method from [1] and [2]. The method is based on the plug-and-play (PnP) framework. 

MAIN BID function: Main_BID_PnP.m 

DEMO SCRIPTS: Demo_BID_PnP.m
%===================================================================================================%

FOLDERS/FILES discription:

Folder - Deblurring:
	BM3D - folder contains Matlab code for BM3D denoising.
	Denoising and mixture -  folder contains Matlab code for GMM-based denoising.
	Patch related - folder contains Matlab functions for patches manipulation.
	estimation_H.m/estimation_H_motion_l1.m - functions for kernel estimation.
	estimation_X.m/estimation_X_bm3d.m/estimation_X_Dictionary.m - functions for image estimation.
Folder - Images:
	Contains images used to perform experiments.
Folder - ISNR_for_BID: 
	Contains ISNR related functions.
Folder - KSVD_Matlab_Toolbox:
	Folder contains Matlab code for Dictionary-based denoising (K-SVD).
Folder - Results:
	For results saving.
%===================================================================================================%


CONTACT:

 Marina Ljubenovic
 Instituto de Telecomunica��es, Lisbon, Portugal
 marina.ljubenovic@lx.it.pt

 Mario A. T. Figueiredo
 Instituto de Telecomunica��es, Lisbon, Portugal
 mario.figueiredo@lx.it.pt
%===================================================================================================%


REFERENCES:

 [1] M. Ljubenovic and M. A. T. Figueiredo, "Blind image deblurring using class-adapted image priors", 
       IEEE International Conf. on Image Processing � ICIP, Beijing, China, September, 2017. (CONFERENCE paper)
 [2] M. Ljubenovic, L. Zhuang and M. A. T. Figueiredo, "Class-adapted blind deblurring of document images",
       The 14th IAPR International Conference on Document Analysis and Recognition - ICDAR, Kyoto, Japan, 2017. (CONFERENCE paper)
%===================================================================================================%


LICENCE:

This code is copyright of M�rio A. T. Figueiredo and Marina Ljubenovic. 
Free permission is given for their use for nonprofit research purposes. 
Any other use is prohibited, unless a license is previously obtained. 