
% estimation_X_Dictionary: Image estimation function
% Image prior/denoiser: Dictionary
% 
% % Input:
% f - original image
% y - blurred image
% h - blurring kernel
% D - existing dictionary
% lambda - regularization param
%
% % Output:
% x - estimated image
% xprev - previous image
%
% Marina Ljubenovic, February 2017
% Adapted code from: Afonso M. A. M. Teodoro

function [x, xprev] = estimation_X_Dictionary(f, y, h, D, lambda, opt)

% Dictionary init
pd = 6;         % patch size
sf = 4;         % sliding factor
C = 1.15;       % Param for K-SVD denoising

admm_iter = 10;

% Define the function handles that compute the blur and the conjugate blur
R = @(h,x) real(ifft2(fft2(h).*fft2(x)));
RT = @(h,x) real(ifft2(conj(fft2(h)).*fft2(x)));

invLS = @(x, mu, filter_FFT) (1/mu)*( x - real( ifft2( filter_FFT.*fft2( x ) ) ) );

try opt.x;
    x = opt.x;
catch
    x = y;
end

%% ADMM loop 

r0 = R(h,x) - y;
 
H_FFT = fft2(h);
H2 = abs(H_FFT).^2;

% ADMM Loop
    for i = 1:admm_iter
      
        if i == 1
            filter_FFT = H2./(H2 + lambda);
            
            % initializing      
            v = x;        
            r = r0;  
            d = r;
        end
       
        dprev = d;
        vprev = v;
        xprev = x;
    
        r = lambda*(v + dprev) + RT(h,y);
    
        x = invLS(r, lambda, filter_FFT);

        % Estimate noise level
        sigma_hat = NoiseEstimation(x-dprev, 8);
        if sigma_hat < 2/255
            sigma_hat = 2/255;
        end
        
        % Prepare image for denoising
        temp = x-dprev;
        temp(temp>1) = 1;
        temp(temp<0) = 0;

             [v, ~] = denoiseImageGlobal(temp, sigma_hat, ...
            'givenDictionary',D,'slidingFactor',sf,'waitBarOn',0,...
            'blockSize',pd, 'numKSVDIters',15,...
            'errorFactor', C);
      
        d = dprev - (x - v);

    end