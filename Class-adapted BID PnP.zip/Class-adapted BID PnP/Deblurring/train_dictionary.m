function [Dictionary, output] = train_dictionary(database, extension, pd)

% Train a new dictionary from external database of clean images

cd ..

if exist(strcat(database, '.mat'), 'file')
    fprintf('Custom dictionary for %s dataset already exists. Loading the dictionary...\n', database)
    saveas = database;
else
    fprintf('Custom dictionary for %s dataset does not exist. Training the dictionary...\n', database)
    
    % path = pwd;
    % directory = strcat(path, '\Database\');
    
    directory = 'C:\Users\User\Desktop\Dictionary-based class-adapted blind deblurring\Database\';
    directory = strcat(strcat(directory, database), '\');
    filetype = strcat('\*.', extension);
    srcFiles = dir(strcat(directory, filetype));  % the folder in which images exists
    srcFiles = srcFiles([srcFiles.bytes]>5000);  % add for Windows
    
    for ps = 2;
        
        db_patches = [];
        y_patches_total = [];
        
        rng('default');
        samples = randperm(length(srcFiles), min(length(srcFiles), 100));
        numim = 0;
        for i = samples
            filename = strcat(directory,srcFiles(i).name);
            try
                x = rgb2gray(imread(filename, extension));
            catch
                x = (imread(filename, extension));
            end
            %x = x(15:94, 10:69);
            x = double(x)/255;
%             global_dc = mean(x(:));
%             x = x - global_dc;
            xx = wextend(2,'sym',x,[pd-1,pd-1]);
            
            y_patches_total = [];
            y_patches = im2colstep(xx,[pd,pd],[ps,ps]);
            [y_patches_ac,y_patches_dc] = remove_dc(y_patches, 'columns');
            y_patches_total = [y_patches_total, y_patches_ac];
            
            %             yyrot = xx;
            %             for i = 1:3
            %
            %                 yyrot = rot90(yyrot);
            %                 y_patches_ac = im2colstep(yyrot,[pd,pd],[ps,ps]);
            %                 y_patches_total = [y_patches_total, y_patches_ac];
            %
            %             end
            
            x_patches_ac = y_patches_total;
            
            db_patches = [db_patches, x_patches_ac];
            numim = numim + 1;
            
                        if size(db_patches, 2) > 512^2
                            % Too many patches
                            break
                        end
        end
        
        fprintf('Training dictionary with %d patches from %d images. \n', size(db_patches, 2), numim)
        
        param.L = 3;   % number of elements in each linear combination.
        param.K = 50; % number of dictionary elements
        param.numIteration = 50; % number of iteration to execute the K-SVD algorithm.

        param.errorFlag = 0; % decompose signals until a certain error is reached. do not use fix number of coefficients.
        % param.errorGoal = sigma;
        param.preserveDCAtom = 0;

        %%%%%%% creating the data to train on %%%%%%%%
%         N = 1500; % number of signals to generate
%         n = 20;   % dimension of each data
%         SNRdB = 20; % level of noise to be added
%         [param.TrueDictionary, D, x] = gererateSyntheticDictionaryAndData(N, param.L, n, param.K, SNRdB);
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %%%%%%%% initial dictionary: Dictionary elements %%%%%%%%
        param.InitializationMethod = 'DataElements';

        param.displayProgress = 1;
        
        [Dictionary,output]  = KSVD(db_patches,param);
        
%         [prob,Scomp,Ucomp,~] = ...
%             adaptive_EM_zeromean(db_patches,K,...
%             2/255,1,1e-5,0,0,0,0,0);

        
        RR = 4; % redundancy factor
        K = RR*pd^2; % number of atoms in the dictionary
        I = displayDictionaryElementsAsImage(Dictionary, floor(sqrt(K)), floor(size(Dictionary,2)/floor(sqrt(K))), pd, pd, 0);
        
%         saveas = strcat(database, strcat(strcat('pd', num2str(pd), strcat(strcat('K', num2str(K)), strcat('ps', num2str(ps))))));
%         save(saveas, 'Dictionary');
    end
end