function [h] = nonlinear_motion_blur(filter_size)

l_size =  round( (filter_size-1)/2 );
lx = l_size(1); 
ly = l_size(2);

h = zeros(filter_size(1),filter_size(2));
h(lx:lx+3, ly+1) = 1;
h(lx-2:lx-1, ly) = 1;
h(lx-3, ly-2:ly) = 1;
h(lx-2:lx+3, ly-3) = 1;

h(lx+4, ly-2) = 1;
h(lx+5:lx+6, ly-3) = 1;

h(lx+4, ly+2:ly+4) = 1;
h(lx-2:lx+4, ly+5) = 1;
h(lx-2:lx-4, ly+6) = 1;

h = h/sum(h(:));