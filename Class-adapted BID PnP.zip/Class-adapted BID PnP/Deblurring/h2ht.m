% function [ht] = h2ht(h,fsize)
%
% Receives a filter "h" at the spectral origin (pixel (1,1)), and 
% returns a filter "ht" of a smaller size ( 2*fsize+1 x 2*fsize+1 )
% and centered at the center of the "ht" matrix. 
%
%
% Mariana S. C. Almeida, 2013.
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@gmail.com
 
function [ht] = h2ht(h,fx, fy)
 
 
h = fftshift(h);

aux = zeros(size(h)); aux(1,1)=1; aux = fftshift(aux);
[c1 c2] = find(aux==1);
 
ht = h( (c1-fx):(c1+fx) , (c2-fy):(c2+fy) );
 
