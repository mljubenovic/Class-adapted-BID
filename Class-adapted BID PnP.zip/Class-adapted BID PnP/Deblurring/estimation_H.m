
% estimation_H: Blur kernel estimation
% Blur prior: Positivity and support
% 
% % Input:
% y - blurred image
% x - previusly estimated image
%
% % Output:
% h - estimated kernel
%
% Marina Ljubenovic, February 2017
% Adapted code from: Mariana S. C. Almeida [1]

%     [1] M. S. C. Almeida and M. A. T. Figueiredo, "Blind Image Deblurring with Unknown Boundaries Using the
%     Alternating Direction Method of Multipliers", IEEE International Conf. on Image Processing � ICIP�2013,
%     Melbourne, Australia, September, 2013. 

function [h] = estimation_H(y,x,filter_size,opt)

ctr_continue = 0;
ctr_positive = 1;

l_size = round((filter_size-1)/2);
lx_blur = l_size(1);     ly_blur = l_size(2);

try opt.h;
    h = opt.h;
catch
    h = zeros(size(x));    h(1,1) = 1;
end

persistent max_iter             
persistent ctr_adapt    t_up      t_down       ro
persistent sz1   sz2


miu_xh = 0.01;      % Default value = 0.01
miu_ph = 0.1;

if ~ctr_continue
    max_iter = 2;
    ctr_adapt = 1;
    t_up = 2;
    t_down = 2;
    ro = 10;
    
    [sz1, sz2] = size(x);
end

% % % % % ADMM INITIALIZATIONS:
x_f = fft2(x);
x_f_conj = conj(x_f);
xTx_f = x_f_conj.*x_f;
h_f = fft2(h);
xh_f = x_f.*h_f;
xh = ifft2(xh_f);

g_xh = xh;
g_ph = h;   % h2ht(h,fsize);
d_xh = 0*g_xh;
d_ph = 0*g_ph;
% % % % % ADMM INITIALIZATIONS (end)

for iter = 1:max_iter
    
    h_old = x;
    g_xh_old = g_xh;
    g_ph_old = g_ph;
    
    % H-step:
    h_f = ( miu_xh.*x_f_conj.*(fft2(g_xh+d_xh)) + miu_ph.*fft2(g_ph+d_ph) ) ./ ( miu_xh.*xTx_f + miu_ph );
    h =  ifft2( h_f );
    % h-setp (end)
    
    % u-steps:
    xh = ifft2(h_f.*x_f);
    g_xh = (y + miu_xh*(xh - d_xh)) ./ (miu_xh + 1);
    
    g_ph_ht =  h2ht( h-d_ph , lx_blur,ly_blur );
    if ctr_positive          g_ph_ht = g_ph_ht.*(g_ph_ht>0);     end
    g_ph = ht2h( g_ph_ht , sz1,sz2 );
    % u-setps (end)
    
    % d-steps:
    d_ph_old = d_ph;
    d_xh_old = d_xh;
    
    r_xh = xh - g_xh;
    d_xh = d_xh - r_xh;
    
    r_ph = h - g_ph;
    d_ph = d_ph - r_ph;
    % d-steps (end)
        
    if ctr_adapt
        
        % Adapt miu_ph:
        s_ph = miu_ph.*(-1)*( (g_ph-g_ph_old) );
        rn_ph = norm(r_ph(:),'fro');
        sn_ph = norm(s_ph(:),'fro');
        if rn_ph > ro*sn_ph,       miu_ph = t_up * miu_ph;
        elseif sn_ph > ro*rn_ph;   miu_ph = miu_ph / t_down;
        end
        
        % Adapt miu_xh:
        s_xh = miu_xh.*(-1)*ifft2( (x_f_conj).*fft2(g_xh-g_xh_old) );
        sn_xh = norm(s_xh(:),'fro');
        rn_xh = norm(r_xh(:),'fro');
        if rn_xh > ro*sn_xh,       miu_xh = t_up * miu_xh;
        elseif sn_xh > ro*rn_xh;   miu_xh = miu_xh / t_down;
        end
              
    end
      
end

h = h.*(h>=0);
end




