%
% Demo_INSR_BID: Demo of an adapted ISNR measure for the BID problem.
%                This measure was first propose din [1] and consists of computing the ISNR
%                after agnling (both the image estimat and the blrured image) with the shape
%                and adjusting their intensity values with and affined
%                transformation.
%
% [1] M. S. C. Almeida and L. B. Almeida, "Blind and Semi-Blind Deblurring of Natural Images",
%     IEEE Trans. Image Processing, Vol.19, pp. 36-52, January, 2010.
%
% Mariana S. C. Almeida
% Instituto de Telecomunica��es, Lisbon, Portugal
% marianascalmeida@gmail.com


clear all,
close all,

cd ..
load Camera9x9_30dB    % Loads the results obtained using the BID method of [1] (and assuming UBC)
                       % after deblurring the cameraman image, degraded with a 9x9 uniform blur, at 30dB of BSNR.
cd ISNR_for_BID

% - Comuting ISNR measures:
fprintf('Computing ISNR measures:')
for it = 1:size(XX,3)
    x_it = XX(:,:,it);
    offset = 2;
    ISNR_res1(it) = ISNR_BID(x_it,x0,y,  offset, 1);  % with resolution of 1 pixel.
    ISNR_res3(it) = ISNR_BID(x_it,x0,y,  offset, 3);  % with resolution of 1/3 of pixel.
    fprintf('.')
end;


% - Extracting the best estimate (best iterations), base on:
%   1) ISNR_res1 , ISNR_res3
[maxi it_isnr1] = max(ISNR_res1);
[maxi it_isnr3] = max(ISNR_res3);


% PLOT image:
scrsz = get(0,'ScreenSize');
figure('Position',[scrsz(3)/6 scrsz(4)*1/3 scrsz(4)/2 scrsz(4)/2])
imagesc( XX(:,:,it_isnr3) ), colormap gray, axis image,
title(strcat('image estimate - it=',num2str(it_isnr3)))
drawnow
