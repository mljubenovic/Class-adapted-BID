%
% function  [x0a ya si sj] = Alignment_Global( x0, y, delta , res);
% 
% Aligns image y relatively to x0. 
% The image to be aligned (y) may have a larger size than x0, 
% as may happen in the case of Unknown Boundary Conditions (UBC).
%
% Input:
%    x0  - reference image to perform the alignment.
%    y   - image to be aligned with x0.
%    delta  - maximal alignment size (in pixels). (default = 4)
%    res    - alignment resolution. (default = 1)
%
%  Output:
%    x0a  - image x0 after alignment.
%    ya   - image y after alignment.
%    si   - number of pixels (multiple of 1/res) that the image y was shift
%           in the 1st dimension in order to become align with x0.
%    sj   - number of pixels (multiple of 1/res) that the image y was shift 
%           in the 2nd dimension in order to become align with x0.
%
% Mariana S. C. Almeida
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@gmail.com
 
 
function  [x0a ya si sj] = Alignment_Global( x0, y, delta , res);
 
[sz1_x0 sz2_x0] = size(x0);
[sz1_y  sz2_y] = size(y);
delta1 = (sz1_y-sz1_x0)/2;
delta2 = (sz2_y-sz2_x0)/2;
 
if nargin == 2,     delta = 4;  res = 1;
elseif nargin == 3, res = 1;  end
 
% Test if delta1 and delta2 are multiples of 1.
if rem(delta1,1)==1  ||  rem(delta2,1)==1
    error(' rem(sz1_y-sz1_x0,1)==1  ||  rem(sz2_y-sz2_x0,1)==1 ');
end
 
 
% 1st alignment: with 1 pixels of resolution 
for i=-delta:delta
    for j=-delta:delta
        yd = circshift(y,[i j]);
        if i==-delta & j==-delta
            min_erro = sum(sum(( (yd( 1+delta1:end-delta1 , 1+delta2:end-delta2 )-x0).^2 )));
            ya1 = yd; 
            si1=i;  sj1=j;
        else
            erro = sum(sum( (yd(1+delta1:end-delta1,1+delta2:end-delta2) - x0 ).^2 ));
            if erro < min_erro
                min_erro = sum(sum( (yd(1+delta1:end-delta1,1+delta2:end-delta2) - x0 ).^2 ));
                ya1 = yd; 
                si1=i;  sj1=j;
            end
        end
    end
end
 
x0_pad = padarray( padarray(x0, (4) , 'circular' )' ,(4) , 'circular')';
ya1_pad = padarray( padarray(ya1, (4) , 'circular' )' ,(4) , 'circular')';
 
x0r_pad=imresize(x0_pad,res,'bicubic');
ya1r_pad=imresize(ya1_pad,res,'bicubic');
x0r = x0r_pad( 1+4*res:end-4*res , 1+4*res:end-4*res );
 
[sz1_x0r sz2_x0r] = size(x0r);
[sz1_ya1r_pad  sz2_ya1r_pad] = size(ya1r_pad);
delta1r = (sz1_ya1r_pad-sz1_x0r)/2;
delta2r = (sz2_ya1r_pad-sz2_x0r)/2;
 
 
% 2nd alignment: with 1/res pixels of resolution
for i=-delta2:delta2
    for j=-delta2:delta2
        yd2 = circshift(ya1r_pad,[i j]);
        if i==-delta2 & j==-delta2
            min_erro2 = sum(sum(((yd2(1+delta1r:end-delta1r,1+delta2r:end-delta2r)-x0r).^2)));
            ya2r = yd2;
            si2=i;  sj2=j;
        else
            erro2 =  sum(sum(((yd2(1+delta1r:end-delta1r,1+delta2r:end-delta2r)-x0r).^2)));
            if erro2<min_erro2
                min_erro2 = sum(sum(((yd2(1+delta1r:end-delta1r,1+delta2r:end-delta2r)-x0r).^2)));
                ya2r = yd2; 
                si2=i;  sj2=j;
            end
        end
    end
end
 
% % Reduction
ya_pad = imresize( ya2r , 1/res , 'bicubic' ); 
ya = ya_pad( 1+4:end-4 , 1+4:end-4 );
x0_pad = imresize( x0r_pad , 1/res , 'bicubic' ); 
x0a = x0_pad( 1+4:end-4 , 1+4:end-4 );
 
si = si1+si2/res;
sj = sj1+sj2/res;


