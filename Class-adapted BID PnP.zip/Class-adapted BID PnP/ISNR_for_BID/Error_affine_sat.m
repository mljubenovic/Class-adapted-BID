%
% function [error xout param] = Error_affine_sat(x,x0);
%
% Computes the affine transformation of x that minimizes ||affine(x)-x0|| and 
% saturates the intensity of the adjusted x image within the range of x0.
% Returns the adjusted x image (xout), the parameters of the affine transformation (param)
% and the final error (after affine transformation and saturation).
%
% Mariana S. C. Almeida
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@gmail.com
 
function [erro xout param] = Error_affine_sat(x,x0);
 
param0 = [1 0];
x_1D = reshape( x,1,[] );
x0_1D = reshape( x0,1,[] );
param = nlinfit( x_1D, x0_1D , @AfinFun , param0 );
 
x2 = param(1)*x+param(2);
erro = x2-x0;
xout = min(max( x2 , min(x0(:))) , max(x0(:) ));
erro = xout-x0;
 


