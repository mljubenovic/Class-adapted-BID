% 
% function [ISNR_dB x_sat xa_sat xa  si sj] = ISNR_BID( x,x0,y, offset,res)
%
% Computes and adapted INSR measure to be invariant image translations and
% to affine transformations of the intensity values. 
% This measure was developed for the BID problem, and proposed in [1].
%
% [1] M. S. C. Almeida and L. B. Almeida, "Blind and Semi-Blind Deblurring of Natural Images",
%     IEEE Trans. Image Processing, Vol.19, pp. 36-52, January, 2010.
%
%
% Input:
%    x0  - sharp image of reference.
%    y   - blurred image (should be the size of x0).
%    x   - estimated image. May be larger than x0 and y, 
%          if Unknown Boundary Conditions (UBC) has been considered.
%    delta  - maximal alignment size (in pixels). (default = 4)
%    res    - alignment resolution. (default = 1)
%
%  Output:
%    ISNR_dB - value (in dB) of the adapted ISNR measure.
%    x_affine_sat - image x after the alignment and the intensity adjustment.
%    si   - number of pixels (multiple of 1/res) that the image y was shift 
%           in the 1st dimension (to become align with x0).
%    si   - number of pixels (multiple of 1/res) that the image y was shift 
%           in the 2nd dimension (to become align with x0).
%
% Mariana S. C. Almeida
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@gmail.com
 
function [ISNR_dB x_affine_sat si sj] = ISNR_BID( x,x0,y, offset,res)
 
[sz1_x0 sz2_x0] = size(x0);
[sz1_x  sz2_x] = size(x);
[sz1_y  sz2_y] = size(y);
 
% Test if x0 and y have the same size:
if (sz1_x0~=sz1_y) || (sz2_x0~=sz2_y)
    error(' (sz1_x0~=sz1_y) || (sz2_x0~=sz2_y) ');
end
 
delta1 = (sz1_x-sz1_x0)/2;
delta2 = (sz2_x-sz2_x0)/2;
% Test if delta1 and delta2 are multiples of 1 (are integeres).
if rem(delta1,1)==1  ||  rem(delta2,1)==1
    error(' rem(sz1_y-sz1_x0,2)==1  ||  rem(sz2_y-sz2_x0,2)==1 ');
end

% Image alignment, with resolution of 1/res of pixel 
if offset
    [x0a xa si sj]= Alignment_Global(x0, x, offset, res );
    [x0a ya]= Alignment_Global(x0, y, offset, res ); 
else
    ya = y;
    xa = x;
    x0a = x0;
    si=0; sj=0;
end
 
% Interior of x; image x may (or may not) be larger than x0 and y (is larger if UBC have been considered).
xa_in = xa( 1+delta1:end-delta1 , 1+delta2:end-delta2 );
 
% Adjusts the intensity of xa_in to the range of x0
[error_x x_affine_sat param] = Error_affine_sat( xa_in , x0);
xa_affine = param(1)*xa + param(2);
x_affine_sat = min(max( xa_affine , min(x0(:)) ) , max(x0(:)) );
% Adjusts the intensity of y to the range of x0
[error_y] = Error_affine_sat( ya , x0 );
 
% Computes the adapted ISNR measure:
ISNR_dB = 20*log10(norm(error_y,'fro')/norm(error_x,'fro'));


