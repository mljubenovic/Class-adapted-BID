clear;clc;%close all;

% Load clean images from file
% imagefiles = dir('C:\Users\User\Desktop\BID Plug and Play\KSVD Matlab Toolbox\images'); 
% For text images
%  imagefiles = dir('C:\Users\User\Desktop\BID Plug and Play\text images'); 
%  nfiles = length(imagefiles);    % Number of files found
% % 
%  for ii=14:19
%     currentfilename = imagefiles(ii).name;
%     currentimage = imread(currentfilename);
%     currentimage = double(currentimage);
%     images{ii} = currentimage;
%  end





 % load  'clean_dataset.mat';
 load('clean_dataset_text.mat');


patch_size = 8;
% clean2 = double(clean_dataset{1});
clean2 = double(images_text{1});
Data=[];
for i_img = 1:6
    Data = [Data,im2col(images_text{i_img} , [patch_size,patch_size], 'sliding')];
end

param.K = 300;
param.numIteration = 5 ;

param.errorFlag = 1; % decompose signals until a certain error is reached. do not use fix number of coefficients.
C = 1.15;
% clean2_medifilt=medfilt2(clean2,[3,3]);
% sigma = std(clean2(:) - clean2_medifilt(:));
sigma = 5



param.errorGoal = sigma*C;
param.preserveDCAtom = 0;
param.InitializationMethod = 'DataElements';
param.displayProgress = 1;


if 1 %Learning Dictionary from Data
    addpath('KSVD Matlab Toolbox');
    tic;
    [Dictionary,output] = KSVD(...
        Data,... % an nXN matrix that contins N signals (Y), each of dimension n.
        param);
    % imagesc(output.CoefMatrix(:,1:200))
    toc;
else %Load Dictionary
    %    load TrainedD_ite3_using1stImg;
    load TrainedD_ite5_sigma5_usingAllSamples;
    %     load TrainedD_ite10_sigma30_usingAllSamples;
end





% Generate noisy data

% Image = clean2;
% sigma = 40;
% img_noisy =  Image + sigma*randn(size(Image));% Add white Gaussian noise.
% 
% 
% %% Denoising image by DSVD
% [IOut,output] = denoiseImageGlobal(img_noisy, sigma, ...
%     'givenDictionary',Dictionary,'waitBarOn',1,...
%     'blockSize',patch_size, 'numKSVDIters',10,...
%     'errorFactor', C);
% 
% 
% %% Denoising image by BM3D
% % addpath('C:\1Denoising\FastHyDe\codes');
% % [PSNR, y_BM3D] = BM3D(1, img_noisy,  sigma);
% %  y_BM3D = y_BM3D*255;
% % rmpath('C:\1Denoising\FastHyDe\codes');
% 
% 
% 
% 
% figure;
% subplot(1,4,1);imshow(Image./255);
% title('Clean');
% subplot(1,4,2); imshow(img_noisy./255);
% title({'Noisy',num2str(sqrt(mean(vec(img_noisy-Image).^2))),[num2str(snr(Image,img_noisy-Image)),' dB']});
% subplot(1,4,3); imshow(IOut./255);
% title({'Denoised by K-SVD',num2str(sqrt(mean(vec(IOut-Image).^2))),[num2str(snr(Image,IOut-Image)),' dB']});
% subplot(1,4,4); imshow(y_BM3D./255);
% title({'Denoised by BM3D',num2str(sqrt(mean(vec(y_BM3D-Image).^2))),[num2str( snr(Image,y_BM3D-Image)),' dB']});


%% show Dictionary:
%  figure;
% for ip=1:100
%     subplot(10,10,ip);
%     imagesc(reshape(Dictionary(:,ip),10, 10)./255);
% end


