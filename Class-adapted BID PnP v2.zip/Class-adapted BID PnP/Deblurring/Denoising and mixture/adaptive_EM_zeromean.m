function [bestpp,bestcovS,bestcovU,best_loglike_s, indic] = ...
    adaptive_EM_zeromean(y,initial_k,sigma,randstarts,th,...
    covoption,k_adaptive,prob,Scomp,Ucomp)
%
% y = data matrix  (number of rows = number of variables;
%                   number of colums = number of points)
%
% k = number of components
%
% randstarts = number of random starts
%
% th = stopping threshold for EM
%
% covoption = 0   ->  free covariances
% covoption = 1   ->  diagonal covariances
% covoption = 2   ->  common covariance for all components
%
% bestpp = estimate of the component probabilities
% bestcov = estimate of the covariances
% best_loglike_s = evolution of the loglikelihood in the best run.
%
%
% Copyright Mario A. T. Figueiredo  mtf@lx.it.pt
% 2001
%
%

% rng('default')
randn('seed', 0);

% Experimentar este par???metro!!! ##########################################
% Altera a 'agressividade' do algoritmo de estima??????o do n???mero de
% componentes
factor = 3;

verb = 0;
[dimens,npoints] = size(y);
mrank = dimens;
initial_prob = prob;
%mrank = 50;
kmin = 10;

pd = sqrt(dimens);
sigma2 = sigma^2;
%eyesigma2 = eye(dimens)*sigma2;

%regularization = 1e-5*eye(dimens);
regularization = eps*eye(dimens);
reg = 1e-5;

tau = 1;
beta1 = 1;
betamax = 4;
going_up = 1;
going_down = 0;

%globcov = cov(y');
%regularize = eye(dimens)*0.002*max(diag(globcov));

maxloglike = -realmax;
startn = 0;

truncate = 0;
indic = zeros(initial_k,npoints);
%estmu = zeros(dimens,initial_k);

ro = 10*sigma*255;

% initial mixture
probi = prob;
Scompi = Scomp;
Ucompi = Ucomp;
covToeplitz = zeros(dimens,dimens,initial_k);
%fprintf('Estimating GMM - Num Patches: %d; Patch Size: %d; Num Components: %d \n', npoints, sqrt(dimens), initial_k)

while startn < randstarts
    
    k = initial_k;
    iter = 1;
    loglike_s = [];
    startn = startn + 1;
    breakflag = 0;
    %       prob = initial_prob;
    
    %       randindex = randperm(npoints);
    %       randindex = randindex(1:k);
    %       estmu = y(:,randindex);
    if initial_k >= length(prob)
        if (prob==0) % no initialization was provided
            Ucomp = zeros(dimens,dimens,k);
            Scomp = zeros(dimens,k);
            prob = (1/k)*ones(k,1);
            globcov = (y*y')/npoints;
            ro = 0;
            %         rng('default')
            rand('seed', 0);
            
            for i=1:k
                estcovar = diag((0.5+0.3*rand(1,dimens))*0.95*max(diag(globcov)));
                [UUU,SSS] = svd(estcovar);
                Ucomp(:,:,i) = UUU;
                Scomp(:,i) = diag(SSS);
            end
            probi = prob;
            Scompi = Scomp;
            Ucompi = Ucomp;
            Ucomp2 = Ucomp;
            
        else
            fprintf('Adding %d components to the mixture\n', initial_k-length(probi))
            Ucomp = zeros(dimens,dimens,k);
            Ucomp(:,:,1:length(prob)) = Ucompi;
            Scomp = zeros(dimens,k);
            Scomp(:, 1:length(prob)) = Scompi;
            globcov = (y*y')/npoints;
            %ro = 0;
            %         rng('default')
            rand('seed', 0);
            
            for i=length(prob)+1:k
                estcovar = diag((0.5+0.3*rand(1,dimens))*0.95*max(diag(globcov)));
                [UUU,SSS] = svd(estcovar);
                Ucomp(:,:,i) = UUU;
                Scomp(:,i) = diag(SSS);
            end
            prob = max(probi)*ones(k,1);
            prob(1:length(probi)) = probi;
            prob = prob/sum(prob);

            probi = prob;
            Scompi = Scomp;
            Ucompi = Ucomp;
        
        end
    end
    
    maxloglike = -realmax;
    
    prevloglike = -realmax;
    cont = 1;
    beta = beta1;
    while(cont) % EM loop
        
        %         x_hat = mix_Wiener(y,prob,estmu,estcovar,[],sigma);
        %         sigma = mean( (y(:)-x_hat(:)).^2 );
        %
        
        
        if k_adaptive ~= 0
            indic = zeros(k,npoints);
        end
        
        for mod=1:k
            indic(mod,:) = prob(mod)*multinorm_svd_zeromean(y,...
                Scomp(:,mod)+sigma2,Ucomp(:,:,mod));
        end
        
        normindic = bsxfun(@times,indic.^beta,1./(realmin + sum(indic.^beta,1)));
        nk = sum(normindic,2);
        alpha = nk./(nk + ro);
        alpha(isnan(alpha)) = 0;
        %alpha = ones(size(prob));
        %alpha = 0.5*ones(size(probi));
        %           aux = bsxfun(@times,y,normindic(1,:)/sum(normindic(1,:)));
        %           estcov = (aux*y');
        %           estcov = diag(ones(1,length(estcov))*mean(diag(estcov)));
        %           [Ucomp(:,:,1),S] = svd(estcov);
        %           Scomp(:,1) = max(diag(S)-sigma2,0);
        %           Scomp(mrank+1:end,1) = 0;
        %           dim_comp(1) = 1;
        
        
        for mod=1:k
            
            
                aux = bsxfun(@times,y,normindic(mod,:)/(eps+sum(normindic(mod,:))));
                estcov = alpha(mod)*(aux*y') + (1-alpha(mod))*Ucompi(:,:,mod)*bsxfun(@times,Scompi(:,mod),Ucompi(:,:,mod)');
            
            if covoption == 1
                estcov = diag(diag(estcov));
            end
            if covoption == 2
                estcovar(:,:,mod) = estcov;
            end
            
%             temp = estcov;
%             sumDiags = blkproc(temp,[pd pd],'convertToeplitz');
%             for i = 2:pd
%                 sumDiags(i,:) = circshift(sumDiags(i-1,:), [0 -sqrt(dimens)]);
%                 sumDiags(i,end-sqrt(dimens)+1:end) = zeros(1, sqrt(dimens));
%             end
%             
%             sumDiags2 = sum(sumDiags, 1);
%             weightscov = repmat(pd:-1:1, 1, pd);
%             mult = repmat(pd:-1:1, pd, 1);
%             mult = mult(:)';
%             diagonals = sumDiags2./(mult.*weightscov);
%             %blocks = cell(6);
%             toeplitzM = zeros(dimens);
%             for j = 1:pd
%                 blocks{j} = zeros(pd);
%                 for i=1:pd
%                     blocks{j} = blocks{j} + diag(diagonals((pd*(j-1))+abs(i))*ones(size(diag(blocks{j},i-1))), i-1);
%                 end
%                 blocks{j} = blocks{j}' + triu(blocks{j},1);
%                 temp2 = repmat(blocks(j), pd-j+1,1);
%                 toeplitzM(1:(pd-j+1)*pd, (j-1)*pd + 1:end) = toeplitzM(1:(pd-j+1)*pd, (j-1)*pd + 1:end) + blkdiag(temp2{:});
%             end
%             covToeplitz(:,:,mod) = triu(toeplitzM)' + triu(toeplitzM, 1);
%             
%             [Ucomp(:,:,mod),S, Ucomp2(:,:,mod)] = svd(covToeplitz(:,:,mod)+regularization);
%             Scomp(:,mod) = diag(S);
%             if truncate == 1
%                 Scomp(Scomp(:,mod)<0,mod) = 0;
%             else
%                 shift = min(Scomp(Scomp(:,mod)<0,mod));
%                 if ~isempty(shift)
%                     Scomp(:,mod) = Scomp(:,mod) - shift*ones(size(Scomp(:,mod))); 
%                 end
%             end
%             
%             figure(80), imagesc(covToeplitz(:,:,mod))
%             figure(90), imagesc(temp)
%             
%             figure(100), imagesc(Ucomp(:,:,mod)*bsxfun(@times,Scomp(:,mod),Ucomp2(:,:,mod)'))
%             drawnow
            
%             norm(Ucomp(:,:,mod)*diag(Scomp(:,mod))*Ucomp2(:,:,mod)' - (covToeplitz(:,:,mod)+regularization))
%             norm(Ucomp(:,:,mod)*diag(Scomp(:,mod))*Ucomp(:,:,mod)' - (covToeplitz(:,:,mod)+regularization))

% 
            covToeplitz(:,:,mod) = estcov;
            [Ucomp(:,:,mod),S, Ucomp2(:,:,mod)] = svd(covToeplitz(:,:,mod)+regularization);
            Scomp(:,mod) = max(diag(S)-sigma2,0);
            %Ucomp(:, (Scomp(:,mod) == 0), mod) = zeros(dimens, length(find(Scomp(:,mod) == 0)));
            if mrank + 1 <= length(prob)
                Scomp(mrank+1:end, mod) = 0;
            end


            
%             Scomp(:,mod) = max(diag(S)-sigma2,0);
%             weights(:,mod) = ones(size(Scomp(:,mod)))*sqrt(dimens)./(Scomp(:,mod) + 1e-10);
%             Scomp(:,mod) = max(Scomp(:,mod)-weights(:,mod),0);
%             Scomp(mrank+1:end,mod) = 0;
            %indexpos = find(diag(S)>sigma2);
            %S = diag(S(indexpos));
            %estcovar(:,:,mod) =  U(:,indexpos)*S* U(:,indexpos)';
            
            %               if rcond(estcovar(:,:,mod)) < 1e-7
            %                  breakflag = 1
            %               end
%             prob = sum(normindic,2) / npoints;
% 
%              for mod2=1:k
%                  indic(mod2,:) = prob(mod2)*multinorm_svd_zeromean(y,...
%                                        Scomp(:,mod2)+sigma2,Ucomp(:,:,mod2)); 
%              end    
%              normindic = bsxfun(@times,indic,1./sum(indic,1));
        end
        
        if covoption == 2
            comcov = zeros(dimens,dimens);
            for mod = 1:k
                comcov = comcov + prob(mod)*estcovar(:,:,mod);
            end
            for mod = 1:k
                [Ucomp(:,:,mod),S] = svd(comcov);
                Scomp(:,mod) = max(diag(S)-sigma2,0);
                if mrank + 1 <= length(prob)
                    Scomp(mrank+1:end, mod) = 0;
                end
            end
        end
       
        
        if k_adaptive ~= 0 && iter > 10
            for mod = 1:k
                dim_comp(mod) = sum(Scomp(:,mod)>0);
            end
            if covoption == 0
                NN =  ((dim_comp.^2 + dim_comp)/2 )';
            else
                NN = dim_comp' ;
            end
            prob = max( sum(normindic,2) - NN/factor, 0);
            prob = prob/sum(prob);
            keep = find(prob > 0 );
            [B, I] = sort(prob, 'descend');
            
            if length(prob(keep)) <= kmin
                keep = I(1:kmin);
            end
            prob = prob(keep);
            Scomp = Scomp(:,keep);
            Ucomp = Ucomp(:,:,keep);
            dim_comp = dim_comp(keep);
            k = length(prob);
        else
            prob = alpha.*(sum(normindic,2) / npoints) + (1-alpha).*(probi);
            prob = prob/sum(prob);
        end
        
        loglike = sum(log(sum(indic)));
        
        deltlike = loglike - prevloglike;
        if (verb~=0)
            fprintf(...
                'iter = %g, k = %g, logL = %0.5g, deltalogL/th = %0.7g\n', ...
                iter, k, loglike, abs(deltlike/loglike)/th);
        end
        
        if abs(deltlike/loglike) < th
            cont = 0;
        end
        
        loglike_s(iter) = loglike;
        iter = iter + 1;
        
        if iter > 100
            cont = 0;
        end
        
        if iter > 10 && isnan(abs(deltlike/loglike)/th)
            cont = 0;
            startn = startn - 1;
            loglike = -realmax;
            prob = 0;
            sigma = sigma*2;
            sigma2 = sigma^2;
        end
        
        if breakflag == 1
            cont = 0;
            loglike = -realmax;
            startn = startn - 1;
        end
        
        prevloglike = loglike;
        
        if going_up
            beta = beta*tau;
        else if going_down
                beta = beta/tau;
            end
        end
        
        if going_up && (beta >= betamax)
            going_up = 0;
            going_down = 1;
        end
        if going_down&&(beta <= 1)
            going_down = 0;
            beta = 1;
        end
       
        
    end % the EM loop
    
    if loglike > maxloglike
        best_loglike_s = loglike_s;
        maxloglike = loglike;
        bestcovS = Scomp;
        bestcovU = Ucomp;
        bestpp = prob;
    end
    
end % the random starts loop



