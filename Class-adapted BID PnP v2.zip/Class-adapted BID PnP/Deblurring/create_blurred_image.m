
% Create blur image with chosen experiment
%
% % Input:
% f - original image
% BSNR - noise level
%
% experiment_no (type of blur):
% 1 - Gaussian; 2 - linear motion; 3 - out-of-focus;  
% 4 - uniform; 5 - synthetic nonlinear motion
% 11 to 18 - motion blurres from Levin 2009
%
% % Output:
% y - blurred and noisy image
% f_blur - blurred image
%
% Marina Ljubenovic, February 2017

function [y, f_blur, sigma] = create_blurred_image(f, experiment_no, BSNR)

% Blur dimensions
blur_dim = 9; % for experiment_no 1 to 5

[fM,fN] = size(f);

% Create blurring filter
[hshift,h_init] = blurimage(f, experiment_no, blur_dim);
   
% Define the function handles that compute the blur 
R = @(h,x) real(ifft2(fft2(h).*fft2(x)));

% Create a blurred and noisy observation
f_blur = R(hshift,f);
sigma = sqrt(norm(f_blur(:)-mean(f_blur(:)),2)^2 /(fM*fN*10^(BSNR/10)));

randn('seed',0);
y = f_blur + sigma*randn(fM, fN);
