%
% function [h] = ht2h(ht, sz1 ,sz2)
%
% Receives a filter "ht" centered at the center of the matrix "ht", and 
% returns a filter "h" equivalent to the filter "ht",
% but of size "sz1"x"sz2" and centered at the spectral origin: pixel (1,1) 
%
% Mariana S. C. Almeida; 2013.
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@gmail.com
%

function [h] = ht2h(ht, sz1 ,sz2)
 
h = zeros(sz1,sz2);
 
auxi = zeros(size(h)); auxi(1,1)=1; auxi = fftshift(auxi);
[c1 c2] = find(auxi==1);

auxi = zeros(size(ht)); auxi(1,1)=1; auxi = fftshift(auxi);
[c1_ht c2_ht] = find(auxi==1);

f11 = c1_ht-1;  f12 = size(ht,1)-c1_ht;
f21 = c1_ht-1;  f22 = size(ht,2)-c1_ht;

h( (c1-f11):(c1+f12) , (c2-f21):(c2+f22) ) = ht;
h = ifftshift(h);
