function [hshift, h, h_orig] = blurimage(input, experiment_number, blur_dim)

[fM,fN]=size(input);

switch experiment_number
    case 1
         % Gaussian
        h  = fspecial('gaussian', [blur_dim blur_dim], 1.6);
        h_orig = h;
    case 2
         % Linear motion
        length = blur_dim;  ang = 135; 
        h =  motion_filter( length, ang);
        h_orig = h;
    case 3
        % Out-of-focus
        h = fspecial('disk',3);
        h_orig = h;
    case 4
        % Uniform
        h = ones(blur_dim,blur_dim);
        h = h./sum(h(:));
        h_orig = h;
    case 5
        % Nonlinear motion
        filter_size = [blur_dim+4 blur_dim+4];
        h = nonlinear_motion_blur(filter_size);
        h_orig = h;
    case 11
        % Motion blur no_1 from Levin 2009
        load('im05_flit01');
        h = rot90(f,2);
        h = h./sum(h(:));
    case 12
        % Motion blur no_2 from Levin 2009
        load('im05_flit02');
        h = rot90(f,2);
        h = h./sum(h(:));
        h_orig = h;
    case 13
        % Motion blur no_3 from Levin 2009
        load('im05_flit03');
        h = rot90(f,2);
        h = h./sum(h(:));
        h_orig = h;
    case 14
        % Motion blur no_4 from Levin 2009
        load('im05_flit04');
        h = rot90(f,2);
        h = h./sum(h(:));
        h_orig = h;
    case 15
        % Motion blur no_5 from Levin 2009
        load('im05_flit05');
        h = rot90(f,2);
        h = h./sum(h(:));
        h_orig = h;
   case 16
        % Motion blur no_6 from Levin 2009
        load('im05_flit06');
        h = rot90(f,2);
        h = h./sum(h(:));
        h_orig = h;
   case 17
        % Motion blur no_7 from Levin 2009
        load('im05_flit07');
        h = rot90(f,2);
        h = h./sum(h(:));
        h_orig = h;
   case 18
        % Motion blur no_8 from Levin 2009
        load('im05_flit08');
        h = rot90(f,2);
        h = h./sum(h(:));
        h_orig = h;
end

hpad = zeros(fM,fN);
hpad(1:size(h,1),1:size(h,2)) = h;

hshift = circshift(hpad, [-floor(size(h,1)/2), -floor(size(h,2)/2)]);



