
% estimation_X_bm3d: Image estimation function
% Image prior/denoiser: BM3D
% 
% % Input:
% f - original image
% y - blurred image
% h - blurring kernel
% lambda - regularization param
%
% % Output:
% x - estimated image
% xprev - previous image
%
% Marina Ljubenovic, February 2017
% Adapted code from: Afonso M. A. M. Teodoro

function [x, xprev] = estimation_X_bm3d(f, y, h, lambda, opt)

% Init
Max_iter = 20;

% Define the function handles that compute the blur and the conjugate blur
R = @(h,x) real(ifft2(fft2(h).*fft2(x)));
RT = @(h,x) real(ifft2(conj(fft2(h)).*fft2(x)));

invLS = @(x, mu, filter_FFT) (1/mu)*( x - real( ifft2( filter_FFT.*fft2( x ) ) ) );

try opt.x;
    x = opt.x;
catch
    x = y;
end

r0 = R(h,x) - y;
 
H_FFT = fft2(h);
H2 = abs(H_FFT).^2;

% ADMM Loop
    for i = 1:Max_iter
      
        if i == 1
            filter_FFT = H2./(H2 + lambda);
                  
            % initializing       
            v = x;
            r = r0;
            d = r;
            
        end
       
        dprev = d;
        vprev = v;
        xprev = x;
    
        r = lambda*(v + dprev) + RT(h,y);
    
        x = invLS(r, lambda, filter_FFT);

        % Estimate noise
        sigma_hat = NoiseEstimation(x-dprev, 8);
        if sigma_hat < 2/255
            sigma_hat = 2/255;
        end
    
        % BM3D denoiser
        % v - image estimate, f -original sharp, x-dprev - noisy image
         [PSNR, v] = BM3D(f, x-dprev, sigma_hat, 'np', 0);
    
    
        d = dprev - (x - v);
    
    end