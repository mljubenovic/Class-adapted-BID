
% estimation_H_motion_l1: Blur kernel estimation
% Blur prior: Sparsity-inducing prior
% 
% % Input:
% y - blurred image
% x - previusly estimated image
% gamma - regularization param.
%
% % Output:
% h - estimated kernel
%
% Marina Ljubenovic, March 2017
% Adapted code from: Mariana S. C. Almeida [1]

%     [1] M. S. C. Almeida and M. A. T. Figueiredo, "Blind Image Deblurring with Unknown Boundaries Using the
%     Alternating Direction Method of Multipliers", IEEE International Conf. on Image Processing � ICIP�2013,
%     Melbourne, Australia, September, 2013. 

function [h] = estimation_H_motion_l1(y,x,gamma,opt)

ctr_continue = 0;
% ctr_positive = 1;


% Initialize h as an identity filter
try opt.h;
    h = opt.h;
catch
    h = zeros(size(x));    h(1,1) = 1;
end

persistent max_iter             
persistent ctr_adapt    t_up      t_down       ro

miu1 = gamma; 
miu2 = 1;

if ~ctr_continue
    max_iter = 20;
    
    ctr_adapt = 0;
    t_up = 2;
    t_down = 2;
    ro = 10;
    
    % [sz1, sz2] = size(x);
end

% % % % % ADMM INITIALIZATIONS:
x_f = fft2(x);
x_f_conj = conj(x_f);
xTx_f = x_f_conj.*x_f;

h_f = fft2(h);
xh_f = x_f.*h_f;
xh = ifft2(xh_f);

k_xh = xh;
k_ph = h;    
d_xh = 0*k_xh;
d_ph = 0*k_ph;
% % % % % ADMM INITIALIZATIONS (end)

for iter = 1:max_iter
    
    % h-step
    h_f = (miu1.*x_f_conj.*(fft2(k_xh+d_xh)) + miu2.*fft2(k_ph+d_ph) ) ./ (miu1.*xTx_f + miu2);
    h =  ifft2(h_f); 
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % k-step
    xh = ifft2(h_f.*x_f);
    k_xh = (y + miu1*(xh - d_xh)) ./ (miu1 + 1);
    
    % Soft-threshold
    k_ph = wthresh((h - d_ph), 's', gamma/miu2);
        
    % d-steps:
    r_xh = xh - k_xh;
    d_xh = d_xh - r_xh;
    
    r_ph = h - k_ph;
    d_ph = d_ph - r_ph;
    %%%%%%%%%%%%%%%%%%%%%%%%
    
    if ctr_adapt
        
        % Adapt miu2:
        s_ph = miu2 .*(-1)*( (k_ph-k_ph_old) );
        rn_ph = norm(r_ph(:),'fro');
        sn_ph = norm(s_ph(:),'fro');
        if rn_ph > ro*sn_ph,       miu2  = t_up * miu2;
        elseif sn_ph > ro*rn_ph;   miu2  = miu2  / t_down;
        end
        
        % Adapt miu1:
        s_xh = miu1.*(-1)*ifft2( (x_f_conj).*fft2(g_xh-g_xh_old) );
        sn_xh = norm(s_xh(:),'fro');
        rn_xh = norm(r_xh(:),'fro');
        if rn_xh > ro*sn_xh,       miu1 = t_up * miu1;
        elseif sn_xh > ro*rn_xh;   miu1 = miu1 / t_down;
        end
              
    end
      
end

h = h.*(h>=0);
end




