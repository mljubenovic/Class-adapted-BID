% Main_BID_PnP: Main of the class-adapted BID method proposed in [1, 2, 3], based on the plug-and-play framework.
%
%                  
% References on BID:
% [1] M. Ljubenovic and  M. A. T. Figueiredo,  . (JOURNAL paper)
%
% [2] M. Ljubenovic and M. A. T. Figueiredo, "Blind image deblurring using class-adapted image priors", 
%       IEEE International Conf. on Image Processing � ICIP, Beijing, China, September, 2017. (CONFERENCE paper)
% [3] M. Ljubenovic, L. Zhuang and M. A. T. Figueiredo, "Class-adapted blind deblurring of document images",
%       The 14th IAPR International Conference on Document Analysis and Recognition - ICDAR, Kyoto, Japan, 2017. (CONFERENCE paper)
%
% Marina Ljubenovic
% Instituto de Telecomunica��es, Lisbon, Portugal
% marina.ljubenovic@lx.it.pt



function [x_est, h_est] = Main_BID_PnP(image, experiment_number)

addpath ./images

%% Parameters

max_iter = 50;              % Number of overall iterations

print_isnr = 1;             % Flag for ISNR print
plot_figure = 1;            % Plot estimations during iterations

blur_dim = 21;              % Dimensions of the blur filter
filter_size = [blur_dim blur_dim]; 

BSNR = 40;                  % Noise level

ctr_recentra = 1;           % If kernel needs to be recentered 

%% Select priors

%%%%% Image prior/denoising %%%%%
% GMM-based denoising - 'gmm' 
% Dictionary-based denoising - 'dictionary'
% BM3D-based denoising - 'bm3d'
image_prior = 'gmm';       

% If selected: image_prior = 'gmm', load pretrained mixture
% GMM options: textpd6K20ps2; facespd6K20ps2; fingerprintspd6K20ps2
database = 'textpd6K20ps2';

% If selected: image_prior = 'dictionary', load pretrained dictionary
% For face images: TrainedD_ite15_sigma5_usingAllImg_size6_1000Atoms_faces
load TrainedD_ite15_sigma5_usingAllImg_size6_1000Atoms; % text dictionary
D = Dictionary;

% Create dictionary with 2 classes, for example D = cat(2, D_text, D_face);  

%%%%% Blur kernel prior %%%%%
% Positivity and support - 'positiv'
% Sparsity-inducing prior - 'spars'
blur_prior = 'spars';

%%%%% Regularization parameters - hand-tuned!
lambda = 0.08;              % image; default lambda = 0.08;
gamma = 0.05;               % kernel; default gamma = 0.05;

%% Load and preprocess image

if isnumeric(image)
    if length(image) == 1   
        switch image
            case 1                  % Input is clear
                % Load CLEAR test image: text_1.png; face_1.png; face_2.png; fing_1.png; text_face_gray.png; text_face_color.png
                f0 = im2double(imread('text_1.png'));              
                blur_exist = 0; 
            case 2                  % Input is blurred
                % Load BLURRED test image: text_cho_blurred.png; real_blurred.png
                f0 = im2double(imread('text_cho_blurred.png'));        
                blur_exist = 1; 
        end
    else
        f0 = image;
    end
else
    try
        f0 = im2double(imread(image));
        if max(max(f0)) > 2
            f0 = double(f0)/255;
        end
    catch
        fprintf(1,'Input image does not exist.\n');
    end
end

% Check whether image is RGB
if size(f0,3)==3
    f = rgb2gray(f0);
else
    f = f0;
end

[fM,fN] = size(f);          

% Add blur and noise
[y, f_blur, sigma] = create_blurred_image(f, experiment_number, BSNR);

% Show blurred and noisy image
y_init = y;
figure(1), imagesc(y_init), colormap(gray(255)), axis off, axis equal

% If input image is already blurred
if blur_exist
y = f;
end

%% Edgetaper!!!!

edge_kernel = [((filter_size(1)-1)/2) ((filter_size(2)-1)/2)];
PSF = fspecial('gaussian',edge_kernel,0.5);
y = edgetaper(y, PSF);

%% Initial PSNR 

bsnr = 10*log10(norm(f_blur(:)-mean(f_blur(:)),2)^2 /sigma^2/fM/fN);
psnr_y = PSNR(f,y_init,1,0);

fprintf('Observation BSNR: %4.2f, PSNR: %4.2f\n', bsnr, psnr_y);

l_size =  round( (filter_size-1)/2 );
lx = l_size(1); 
ly = l_size(2);

%% Main loop

x = y;                          % Init image

X3X = zeros(size(y,1),size(y,2), max_iter);
H3H = zeros(filter_size(1),filter_size(2), max_iter);

for j = 1:max_iter
      
    % Initial value of h
    try opt.h;  
        h = opt.h;  
    catch me, 
        h = zeros(filter_size(1),filter_size(2)); 
        h(lx+1,ly+1) = 1;
        h = h + 0.01*rand(size(h));
        h = h/sum(h(:));
    end 

    h = ht2h( h, fM,fN );

%-------------------------------------------------------------------------  
    % Image estimation 
    optx.x = x;
    
    switch image_prior
        case 'gmm'
            [x, ~] = estimation_X(f, y, h, database, lambda, optx);
        case 'dictionary'
            [x, ~] = estimation_X_Dictionary(f, y, h, D, lambda, optx);
        case 'bm3d'
            [x, ~] = estimation_X_bm3d(f, y, h, lambda, optx);
    end
            
%------------------------------------------------------------------------- 
    % Kernel estimation
    opth.h = h; 
    
    switch blur_prior
        case 'positiv'
            [h0] = estimation_H(y, x, filter_size, opth);
        case 'spars'
            [h0] = estimation_H_motion_l1(y, x, gamma, opth);
    end
    
    % Recenter kernel
    grid_x = meshgrid( (-max(lx,ly):max(lx,ly)) );
    grid_y = grid_x';
    
    if ctr_recentra
        % h1 = h0;
        ht1 = h2ht(h0, lx,ly);
        cm(j,:) = [ sum(sum(grid_y.*ht1))./sum(sum(ht1))  sum(sum(grid_x.*ht1))./sum(sum(ht1)) ];
        d2 = - round( cm(j,2) - 0.30*sign(cm(j,2)) );
        d1 = - round( cm(j,1) - 0.30*sign(cm(j,1)) );
        if d1~=0 || d2~=0
            % Shift image x and re-estimate filter h.
            x = circshift( x , max(min([-d1 -d2],2),-2) );
            switch blur_prior
                case 'positiv'
                    [h0] = estimation_H(y, x, filter_size, opth);
                case 'spars'
                    [h0] = estimation_H_motion_l1(y, x, gamma, opth);
            end
            % h1 = h0;
            ht1 = h2ht(h0, lx,ly);
            cm(j,:) = [ sum(sum(grid_y.*ht1))./sum(sum(ht1))  sum(sum(grid_x.*ht1))./sum(sum(ht1)) ];
        end
    end
    
    h = h0;
    ht =  h2ht(h, lx, ly );    
    h = ht2h(ht, fM, fN );  
    h = h/sum(sum(h(:)));
    
    h = h2ht(h, lx, ly);
    opt.h = h;
 %------------------------------------------------------------------------   
    % Improvament of SNR
    psnr1(j) = PSNR(f,x,1,0);
    % ISNR(j) = psnr1(j)-psnr_y; % for non-blind deblurring
    offset = 2;
    ISNR(j) = ISNR_BID(x, f, y_init, offset, 3);
  
    % Print ISNR over iterations
    if ~mod(j,1)
        if print_isnr && blur_exist == 0
           fprintf(1,'Iteration: %d;\t ISNR = %4.2f\n', j, ISNR(j));
        else
            fprintf(1,'Iteration: %d\n', j);
        end     
    end
    
    % Combine results; Images packed in 3D
    X3X(:,:,j)= x;
    H3H(:,:,j)= h;
    
    % Plot estemeted image, kernel and value of ISNR over iterations
     if plot_figure && blur_exist == 0
        figure(2),
        subplot('position',[0   1-0.57 0.50 0.50]), imagesc(X3X(:,:,j)),  colormap(gray(256)), axis image, 
        title( strcat('Image estimate - it=',num2str(j)) )
        drawnow;
        subplot('position',[0.5 1-0.57 0.50 0.50]), imagesc(H3H(:,:,j)), colormap(gray(256)),  axis image,  
        title( strcat( 'Kernel estimate - it=',num2str(j) ))
        drawnow;
        subplot('position',[0.05 0.05 0.40 0.28]), plot(ISNR),
        title('ISNR') 
        drawnow;
     else 
        figure(2),
        subplot('position',[0   1-0.57 0.50 0.50]), imagesc(X3X(:,:,j)),  colormap(gray(256)), axis image, 
        title( strcat('Image estimate - it=',num2str(j)) )
        drawnow;
        subplot('position',[0.5 1-0.57 0.50 0.50]), imagesc(H3H(:,:,j)), colormap(gray(256)),  axis image,  
        title( strcat( 'Kernel estimate - it=',num2str(j) ))
        drawnow;
     end

    isnr_vec(j) = ISNR(j);

end
%% Show the end results

[isnr_max,Index_max_isnr] = max(isnr_vec);      % Best ISNR

disp('-------- Results --------');
fprintf('Maximum ISNR: %4.2f, Iteration: %d\n', isnr_max, Index_max_isnr);

scrsz = get(0,'ScreenSize');
figure('Position',[scrsz(3)/6 scrsz(4)*1/3 scrsz(4)/2 scrsz(4)/2])
img_est =  X3X(:,:,end);
h2 =  imresize( H3H(:,:,end) , 1.5, 'box'); h2 = h2-min(h2(:)); h2= h2 ./max(h2(:));
img_est( 1:size(h2,1) , end-size(h2,2)+1:end) = h2;
imagesc( max(min(img_est,1),0) ), colormap gray, axis image
% title(strcat('Estimates, ISNR =',num2str(isnr_max)))

% psnr = PSNR(f,x,1,0);                           % End PSNR

% Save the results
x_est = X3X(:,:,end);
imwrite(x_est,['Results\' 'estimated_image.png']);

h_est = H3H(:,:,end);
h_est = h_est - min(h_est(:));
h_est = h_est./max(h_est(:));
imwrite(h_est,['Results\' 'estimated_kernel.png']);


