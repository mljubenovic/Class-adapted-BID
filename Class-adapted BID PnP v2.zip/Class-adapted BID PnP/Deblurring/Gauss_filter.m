% function  [filter] = Gauss_filter(BlurDim,sig);
%
% Returns a filter "filter" with size "BlurDim"x"BlurDim" and
% Gaussian shape with a st.d. of "sigma" pixels.
%
% Mariana S. C. Almeida
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@gmail.com

function [filter] = Gauss_filter(BlurDim,sig);

aux = zeros(BlurDim,BlurDim);
aux(1,1)= 1;
aux = fftshift(aux);
[c1 c2] = find(aux==1);

Vx =(1:BlurDim);
Vy =(1:BlurDim);
[MX MY]=meshgrid(Vx,Vy);
Dcentro = sqrt( (MX-c2).^2 + (MY-c1).^2);
                        
filter = 1/(sig*sqrt(2*pi))*exp(-(Dcentro.^2)./(2*sig^2));
filter = filter./sum(filter(:));
