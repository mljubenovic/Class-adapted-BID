% Demo_BID_PnP: Demo of the class-adapted BID method proposed in [1], [2], and [3], based on the plug-and-play (PnP) framework.
%               
%               Demo applied to a synthetic experiment of TEXT image blurred with a motion blur (no.2 from Levin 2009), at 40dB of BSNR.
%               Number of iterations is set on 50, with a GMM-based denoiser (image prior) and a sparsity-inducing prior on the blurring kernel.
%                  
% References on BID:
% [1] M. Ljubenovic and  M. A. T. Figueiredo (JOURNAL paper)
%
% [2] M. Ljubenovic and M. A. T. Figueiredo, "Blind image deblurring using class-adapted image priors", 
%       IEEE International Conf. on Image Processing � ICIP, Beijing, China, September, 2017. (CONFERENCE paper)
% [3] M. Ljubenovic, L. Zhuang and M. A. T. Figueiredo, "Class-adapted blind deblurring of document images",
%       The 14th IAPR International Conference on Document Analysis and Recognition - ICDAR, Kyoto, Japan, 2017. (CONFERENCE paper)
%
% Marina Ljubenovic
% Instituto de Telecomunica��es, Lisbon, Portugal
% marina.ljubenovic@lx.it.pt

addpath(genpath('./Deblurring'))
addpath(genpath('./ISNR_for_BID'))
addpath(genpath('./KSVD_Matlab_Toolbox'))
addpath ./motion_blur_filters
addpath ./Results


%%%%% Main of the class-adapted BID PnP method
% image (input image): 
% 1 - clean input image
% 2 - blurred input image
%-------------------------------------------------------------------------
% experiment_number (type of blur):
% 1 - Gaussian; 2 - linear motion; 3 - out-of-focus;  
% 4 - uniform; 5 - synthetic nonlinear motion
% 11 to 18 - motion blurres from Levin 2009
%-------------------------------------------------------------------------
% PLEASE GO TO 'Main_BID_PnP' TO CHOOSE AND ADJUST OTHER PARAMETERS!!!

image = 1;
experiment_number = 12;

[x_est, h_est] = Main_BID_PnP(image, experiment_number);

%%%%%%