% function y = AfinFun( Param, x )

function y = AfinFun( Param, x )

a=Param(1);
b=Param(2);

y = a*x+b;